Found within this directory is PlantUML v7999 and Graphiz v2.38<br/>
It has been tested upon Windows 7 64bit as to working.<br/>
Java 7 was used.